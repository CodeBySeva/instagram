export function createProfilePosts(post) {
    const postElem = document.createElement('div');
    postElem.classList.add('post');

    for (const imgUrl of post.imageUrl) {
        const img = document.createElement('img');
        img.src = imgUrl;
        img.classList.add('image');
        postElem.append(img);
    };

    postContainer.append(postElem);

    return postElem;
};